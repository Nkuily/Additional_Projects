USE Garage_Management;
GO

CREATE PROCEDURE CheckAndReorderInventory--This stored procedure will check if the stock levels are below the reorder points and will generate a purchase order if necessary.
AS
BEGIN
    DECLARE @InventoryID INT,
            @Suppliers VARCHAR(100),
            @StockLevelsQuantity INT,
            @ReorderPoints INT,
            @PurchaseOrders INT,
            @NewOrderID INT;

    DECLARE inventory_cursor CURSOR FOR
    SELECT InventoryID, Suppliers, StockLevelsQuantity, ReorderPoints, PurchaseOrders
    FROM InventoryTable
    WHERE StockLevelsQuantity < CAST(ReorderPoints AS INT);

    OPEN inventory_cursor;

    FETCH NEXT FROM inventory_cursor INTO @InventoryID, @Suppliers, @StockLevelsQuantity, @ReorderPoints, @PurchaseOrders;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Generate a new purchase order
        INSERT INTO InventoryTable (Suppliers, StockLevelsQuantity, ReorderPoints, PurchaseOrders)
        VALUES (@Suppliers, 0, @ReorderPoints, 1);  -- Assuming 1 for the new purchase order

        -- Optionally, update the PurchaseOrders column in the original row
        UPDATE InventoryTable
        SET PurchaseOrders = PurchaseOrders + 1
        WHERE InventoryID = @InventoryID;

        FETCH NEXT FROM inventory_cursor INTO @InventoryID, @Suppliers, @StockLevelsQuantity, @ReorderPoints, @PurchaseOrders;
    END;

    CLOSE inventory_cursor;
    DEALLOCATE inventory_cursor;
END;
GO


--This trigger will execute the above stored procedure CheckAndReorderInventory whenever there is an update on the InventoryTable.
USE Garage_Management;
GO

CREATE TRIGGER trg_AfterInventoryUpdate
ON InventoryTable
AFTER INSERT, UPDATE
AS
BEGIN
    -- Execute the stored procedure to check inventory levels and reorder if necessary
    EXEC CheckAndReorderInventory;
END;
GO
