﻿using Microsoft.AspNetCore.Mvc;

namespace SectionBQ2._1.Controllers
{
    [Route("api/[controller]")]
    public class ProductsController : Controller
    {
        // Controller methods go here
    }
}


