USE UniversityManagement;

SELECT Students.StudentName, Courses.CourseName
FROM Students
JOIN Enrolment ON Students.StudentId = Enrolment.StudentId
JOIN Courses ON Enrolment.CourseID = Courses.CourseId;

SELECT Students.StudentName
FROM Students
JOIN Enrolment ON Students.StudentId = Enrolment.StudentId
WHERE Enrolment.CourseID = 'specific_course_id';

SELECT Courses.CourseName
FROM Courses
JOIN Instructors ON Courses.CourseId = Instructors.InstructorId
WHERE Instructors.InstructorName = 'specific_instructor_name';

INSERT INTO Students (StudentId, StudentName, StudentSurname, PhoneNumber, PhysicalAddress)
VALUES (10, 'Judy', 'Fishburn', '083-524-9559', '211 TakeMeHome, Judith Drive');

UPDATE Courses
SET CourseName = 'Political Sciences', CourseDuration_InYears = 4, CurrentCourseStatus = 'About to start studying'
WHERE CourseId = 3;

DELETE FROM Students
WHERE StudentId = 2;




