--Now let's identify slow queries using EXPLAIN, however in SQL Server, you can use the QUERY PLAN statement instead to analyze the execution plan of your queries.

-- So nowdentify slow queries using QUERY PLAN

-- Example query 1: Join between InvoicesTable, CustomersTable, and VehiclesTable
SET SHOWPLAN_TEXT ON;
GO
SELECT i.InvoiceID, c.CustomerName, v.Make, v.Model
FROM InvoicesTable AS i
JOIN CustomersTable AS c ON i.CustomerID = c.CustomerID
JOIN VehiclesTable AS v ON i.VehicleID = v.VehicleID;
GO
SET SHOWPLAN_TEXT OFF;
GO

-- Example query 2: Subquery to find customers with invoices
SET SHOWPLAN_TEXT ON;
GO
SELECT CustomerID, CustomerName
FROM CustomersTable
WHERE CustomerID IN (SELECT DISTINCT CustomerID FROM InvoicesTable);
GO
SET SHOWPLAN_TEXT OFF;
GO

-- Rewrite inefficient queries

-- Rewrite query 1: Join optimization
SELECT i.InvoiceID, c.CustomerName, v.Make, v.Model
FROM InvoicesTable AS i
JOIN CustomersTable AS c ON i.CustomerID = c.CustomerID
JOIN VehiclesTable AS v ON i.VehicleID = v.VehicleID;

-- Rewrite query 2: Subquery elimination using JOIN
SELECT c.CustomerID, c.CustomerName
FROM CustomersTable AS c
JOIN (SELECT DISTINCT CustomerID FROM InvoicesTable) AS inv ON c.CustomerID = inv.CustomerID;
