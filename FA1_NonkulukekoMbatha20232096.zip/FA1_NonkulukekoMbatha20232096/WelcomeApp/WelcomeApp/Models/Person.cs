﻿namespace WelcomeApp.Models
{
    public class Person
    {
        public string Name { get; set; }
        public string Message { get; set; }
    }
}
