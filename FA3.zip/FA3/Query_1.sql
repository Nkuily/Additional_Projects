CREATE DATABASE Garage_Management;

USE Garage_Management;

CREATE TABLE CustomersTable(
CustomerID INT PRIMARY KEY,
CustomerName VARCHAR(50),
CustomerAddress VARCHAR(100),
PhoneNumber BIGINT,
LoyaltyTier VARCHAR(100),
ContactPreference VARCHAR(50)
);

CREATE TABLE VehiclesTable(
VehicleID INT PRIMARY KEY,
CustomerID INT,
LicensePlate VARCHAR(50),
Make VARCHAR(50),
Model VARCHAR(50),
TheYear INT,
VINNumber VARCHAR(100),
Mileage INT,
FuelType VARCHAR(50)
CONSTRAINT FK_VehiclesTable_CustomersTable FOREIGN KEY (CustomerID) REFERENCES CustomersTable(CustomerID)
);

CREATE TABLE ServicesTable(
ServiceID INT PRIMARY KEY,
ServiceDescription VARCHAR(100),
PriceExcludingVAT VARCHAR(50),
LabourHours INT,
WarrantyInMonths INT
);

CREATE TABLE InvoicesTable(
InvoiceID INT PRIMARY KEY,
CustomerID INT,
VehicleID INT,
ServiceID INT,
InvoiceDate DATE,
PaymentMethod VARCHAR(50),
TotalIncludingVAT VARCHAR(100),
Technician VARCHAR(50)
CONSTRAINT FK_InvoicesTable_CustomersTable FOREIGN KEY (CustomerID) REFERENCES CustomersTable(CustomerID),
CONSTRAINT FK_InvoicesTable_VehiclesTable FOREIGN KEY (VehicleID) REFERENCES VehiclesTable(VehicleID),
CONSTRAINT FK_InvoicesTable_ServicesTable FOREIGN KEY (ServiceID) REFERENCES ServicesTable(ServiceID)
);

CREATE TABLE InventoryTable(
InventoryID INT PRIMARY KEY,
Suppliers VARCHAR(100),
StockLevelsQuantity VARCHAR(100),
ReorderPoints VARCHAR(50),
PurchaseOrders INT
);

CREATE TABLE EmployeesTable(
EmployeeID INT PRIMARY KEY,
EmployeeRole VARCHAR(50),
Designation VARCHAR(100),
SalaryOrWage VARCHAR(50),
EmployeeSchedule VARCHAR(100),
EmployeeAccessControlLevel VARCHAR(50)
);

