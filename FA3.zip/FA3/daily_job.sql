-- daily_job.sql script
USE Garage_Management;

EXEC CheckAndReorderInventory;
