﻿using Microsoft.AspNetCore.Mvc;

namespace SectionBQ2._2.Controllers
{
    [Route("api/[controller]")]
    public class ProductController : Controller
    {
        private static List<Product> _products = new List<Product>
    {
        new Product { Id = 1, Name = "Product1", Price = 100 },
        new Product { Id = 2, Name = "Product2", Price = 200 }
    };

        // GET: api/products
        [HttpGet]
        public IEnumerable<Product> GetAllProducts()
        {
            return _products;
        }

        // GET api/products/5
        [HttpGet("{id}")]
        public ActionResult<Product> GetProductById(int id)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            return product;
        }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}



