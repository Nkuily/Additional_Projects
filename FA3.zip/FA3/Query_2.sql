USE Garage_Management;

INSERT INTO CustomersTable(CustomerID, CustomerName, CustomerAddress, PhoneNumber, LoyaltyTier, ContactPreference) VALUES
(1, 'John Doe', '123 Main St, Pretoria', 555123, 'Silver', 'Email'),
(2, 'Jane Smith', '456 Elm St, Centurion', 555456, 'Gold', 'SMS'),
(3, 'Bob Jones', '789 Maple Dr, Johannesburg', 555789, 'Bronze', 'Both'),
(4, 'Jessie Maharaj', '45 Aralia Crescent, Lenasia', 555321, 'Gold', 'SMS');

INSERT INTO VehiclesTable(VehicleID, CustomerID, LicensePlate, Make, Model, TheYear, VINNumber, Mileage, FuelType) VALUES
(1, 1, 'ABC123', 'Toyota', 'Camry', 2018, 'JTDBE41E7K3000001', 50000, 'Petrol'),
(2, 4, 'DEF456', 'Honda', 'Civic', 2020, 'JTQWE41E7K400001', 62000, 'Diesel'),
(3, 2, 'GHI789', 'Ford', 'F-150', 2022, 'JSDFG41E7K3000001', 50000, 'Petrol');

INSERT INTO ServicesTable(ServiceID, ServiceDescription, PriceExcludingVAT, LabourHours, WarrantyInMonths) VALUES
(1,'Oil Change', 'R450', 1, 3),
(2,'Tyre Rotation', 'R300', 0.5, 1),
(3,'Brake Pad Replacement', 'R800', 2, 6);

INSERT INTO InvoicesTable(InvoiceID, CustomerID, VehicleID, ServiceID, InvoiceDate, PaymentMethod, TotalIncludingVAT, Technician) VALUES
(1, 1, 1, 1, '2023.11.21', 'Credit Card', 'R540', 'John Smith'),
(2, 2, 2, 2, '2023.12.15', 'Cash', 'R360', 'Carl Victor');



-- Insert data from the Customers_Table table into the CustomersTable table
INSERT INTO CustomersTable (CustomerID, CustomerName, CustomerAddress, PhoneNumber, LoyaltyTier, ContactPreference)
SELECT CustomerID, CustomerName, CustomerAddress, PhoneNumber, LoyaltyTier, ContactPreference
FROM Customers_Table;

-- Select all data from the CustomersTable table to verify the transfer
SELECT * FROM CustomersTable;

--so what i did above is to transfer the data from the CustomersTable to the new Customers_Table that was imported, 
--so sir the import was successful when its being imported as a flat file, however it forces you to name a new table 
--so i just transferred everything back to my initial table so its with the first few records i had already inserted here on ssms 
--so the same procedure will be performed on the rest of the tables


-- Insert data from the Vehicles_Table table into the VehiclesTable table
INSERT INTO VehiclesTable(VehicleID, CustomerID, LicensePlate, Make, Model, TheYear, VINNumber, Mileage, FuelType) 
SELECT VehicleID, CustomerID, LicensePlate, Make, Model, TheYear, VINNumber, Mileage, FuelType
FROM Vehicles_Table;

-- Select all data from the VehiclesTable table to verify the transfer
SELECT * FROM VehiclesTable;

--Services
INSERT INTO ServicesTable(ServiceID, ServiceDescription, PriceExcludingVAT, LabourHours, WarrantyInMonths)
SELECT ServiceID, ServiceDescription, PriceExcludingVAT, LabourHours, WarrantyInMonths
FROM Services_Table;

-- Select all data from the ServicesTable table to verify the transfer
SELECT * FROM ServicesTable;

--Invoices
INSERT INTO InvoicesTable(InvoiceID, CustomerID, VehicleID, ServiceID, InvoiceDate, PaymentMethod, TotalIncludingVAT, Technician)
SELECT InvoiceID, CustomerID, VehicleID, ServiceID, InvoiceDate, PaymentMethod, TotalIncludingVAT, Technician
FROM Invoices_Table;

-- Select all data from the InvoicesTable table to verify the transfer
SELECT * FROM InvoicesTable;


--Inventory
INSERT INTO InventoryTable(InventoryID, Suppliers, StockLevelsQuantity, ReorderPoints, PurchaseOrders)
SELECT InventoryID, Suppliers, StockLevelsQuantity, ReorderPoints, PurchaseOrders
FROM Inventory_Table;

-- Select all data from the InventoryTable table to verify the transfer
SELECT * FROM InventoryTable;

--Employees
INSERT INTO EmployeesTable(EmployeeID, EmployeeRole, Designation, SalaryOrWage, EmployeeSchedule, EmployeeAccessControlLevel)
SELECT EmployeeID, EmployeeRole, Designation, SalaryOrWage, EmployeeSchedule, EmployeeAccessControlLevel
FROM Employees_Table;

-- Select all data from the EmployeesTable table to verify the transfer
SELECT * FROM EmployeesTable;