CREATE DATABASE UniversityManagement;

USE UniversityManagement;

CREATE TABLE Students(
StudentId INT PRIMARY KEY,
StudentName VARCHAR(50),
StudentSurname VARCHAR(50),
PhoneNumber VARCHAR(25),
PhysicalAddress VARCHAR(100));

CREATE TABLE Courses(
CourseId INT PRIMARY KEY,
CourseName VARCHAR(50),
CourseDuration_InYears INT,
CurrentCourseStatus VARCHAR(50));

CREATE TABLE Instructors(
InstructorId INT PRIMARY KEY,
InstructorName VARCHAR(50),
Department VARCHAR(50),
Email VARCHAR(50));

CREATE TABLE Enrolment(
EnrolmentId INT PRIMARY KEY,
CourseID INT,
StudentId INT,
EnrolmentStatus VARCHAR(50),
FOREIGN KEY (CourseId) REFERENCES Courses(CourseId),
FOREIGN KEY (StudentId) REFERENCES Students(StudentId));

