USE Garage_Management;

CREATE PROCEDURE GenerateInvoice
    @ServiceID INT
AS
BEGIN
    DECLARE @CustomerID INT;
    DECLARE @VehicleID INT;
    DECLARE @TotalServiceCost DECIMAL(10, 2);
    DECLARE @TotalPartsCost DECIMAL(10, 2);
    DECLARE @TotalIncludingVAT DECIMAL(10, 2);
    DECLARE @VATRate DECIMAL(4, 2) = 0.15; -- Example VAT rate of 15%
    DECLARE @Technician VARCHAR(50) = 'John Doe'; -- Example technician, this can be dynamically set
    DECLARE @PaymentMethod VARCHAR(50) = 'Credit Card'; -- Example payment method, this can be dynamically set

    -- Get associated CustomerID and VehicleID
    SELECT @CustomerID = v.CustomerID, @VehicleID = v.VehicleID
    FROM ServicesTable s
    INNER JOIN VehiclesTable v ON a.VehicleID = v.VehicleID
    WHERE s.ServiceID = @ServiceID;

    -- Calculate the total cost of the service
    SELECT @TotalServiceCost = PriceExcludingVAT
    FROM ServicesTable
    WHERE ServiceID = @ServiceID;

    -- Calculate the total cost of the parts used in the service
    SELECT @TotalPartsCost = SUM(p.PartPrice * sp.QuantityUsed)
    FROM PartsTable p
    JOIN ServiceParts sp ON p.PartID = sp.PartID
    WHERE sp.ServiceID = @ServiceID;

    -- Calculate the total cost including VAT
    SET @TotalIncludingVAT = (@TotalServiceCost + @TotalPartsCost) * (1 + @VATRate);

    -- Insert the invoice record
    INSERT INTO InvoicesTable (CustomerID, VehicleID, ServiceID, InvoiceDate, PaymentMethod, TotalIncludingVAT, Technician)
    VALUES (@CustomerID, @VehicleID, @ServiceID, GETDATE(), @PaymentMethod, @TotalIncludingVAT, @Technician);
END;



CREATE TRIGGER trg_AfterServiceComplete
ON ServicesTable
AFTER UPDATE
AS
BEGIN
    DECLARE @ServiceID INT;
    DECLARE @ServiceStatus VARCHAR(50);

    -- Get the ServiceID and ServiceStatus for the updated record
    SELECT @ServiceID = ServiceID, @ServiceStatus = ServiceStatus
    FROM inserted;

    -- Check if the ServiceStatus indicates completion
    IF @ServiceStatus = 'Complete'
    BEGIN
        -- Call the stored procedure to generate an invoice
        EXEC GenerateInvoice @ServiceID;
    END;
END;

