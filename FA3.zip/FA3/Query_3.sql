-- Create indexes on frequently used columns in CustomersTable
CREATE INDEX Indx_Customers_CustomerName ON CustomersTable (CustomerName);
CREATE INDEX Indx_Customers_PhoneNumber ON CustomersTable (PhoneNumber);

-- Create indexes on frequently used columns in VehiclesTable
CREATE INDEX Indx_Vehicles_CustomerID ON VehiclesTable (CustomerID);
CREATE INDEX Indx_Vehicles_LicensePlate ON VehiclesTable (LicensePlate);

-- Create indexes on frequently used columns in InvoicesTable
CREATE INDEX Indx_Invoices_CustomerID ON InvoicesTable (CustomerID);
CREATE INDEX Indx_Invoices_VehicleID ON InvoicesTable (VehicleID);
CREATE INDEX Indx_Invoices_ServiceID ON InvoicesTable (ServiceID);
CREATE INDEX Indx_Invoices_InvoiceDate ON InvoicesTable (InvoiceDate);

-- Create indexes on frequently used columns in InventoryTable
CREATE INDEX Indx_Inventory_Suppliers ON InventoryTable (Suppliers);

-- Create indexes on frequently used columns in EmployeesTable
CREATE INDEX Indx_Employees_EmployeeID ON EmployeesTable(EmployeeID);
CREATE INDEX Indx_Employees_EmployeeRole ON EmployeesTable (EmployeeRole);

-- Now lets sample query without indexes
SELECT * 
FROM CustomersTable 
WHERE LoyaltyTier = 'Gold';

-- Sample query with index on CustomerName
SELECT * 
FROM CustomersTable 
WHERE CustomerName = 'John Doe';
